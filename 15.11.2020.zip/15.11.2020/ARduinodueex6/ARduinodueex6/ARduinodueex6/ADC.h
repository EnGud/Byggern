/*
 * ADC.h
 *
 * Created: 12.11.2020 16:13:00
 *  Author: harasa
 */ 


#ifndef ADC_H_
#define ADC_H_

void adcinit(void);



#endif /* ADC_H_ */