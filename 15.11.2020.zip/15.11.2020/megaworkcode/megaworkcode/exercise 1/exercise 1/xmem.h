/*
 * xmem.h
 *
 * Created: 10.09.2020 10:26:51
 *  Author: harasa
 */ 


#ifndef XMEM_H_
#define XMEM_H_

void init_xmem(void);



#endif /* XMEM_H_ */