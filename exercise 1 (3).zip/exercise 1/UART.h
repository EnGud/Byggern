void UART_init(unsigned long extclock);
uint8_t UART_Recieve(void);
uint8_t UART_Transmit(unsigned char data);

