#include <avr/io.h>
#include <stdbool.h>

#ifndef F_CPU
#define F_CPU 8000000UL
#warning "F_CPU not defined! Assuming 16MHz."
#endif
#define BAUD 9600
#define MYUBBR F_CPU/16/BAUD-1



// here we initialize the uart and set the baud rate
void UART_init(void)
{						
	//set baud rate
	UBRRH = (unsigned char)(MYUBBR>>8);
	UBRRL = (unsigned char)MYUBBR;
	//enable reciever and transmitter
	UCSRB = (1<<RXEN) | (1<<TXEN);
	//set frame format: 8 data, 1 stop bits
	UCSRC = (1<<URSEL) | (3<<USCZO);
	
}

void UART_Transmit(unsigned char data)
{
	while (!(UCSRA & (1<<UDRE))) ;
	UDR = data;
	while(!is_UARTtransmitcomplete());
}

unsigned char UART_Recieve(void)
{
	
	while(!(UCSRA & (1<<RXC)));
	return UDR;
}

static bool is_UARTtransmitcomplete(void)
{
	return UCSR0A (1<<TXC0);
}

static bool is_UARTdataempty(void)
{
return UCSR0A & (1 << UDRE0);	
}

